/*
 * This program finds Optimal codes for given length(6-13) and distance(4,6)
 * 
 */
package example;

/**
 * 
 * @author Nurbek Imangazin (ni15dz@brocku.ca)
 */
public class Optimal {
  
        public int n;//length of the codewords
        public int base;//base (q)
        public int distance;//distance
        public int M;//bound on the table
        public String[] optimal;//optimal code
        public int[] eachLevelCandidatesSize;//
        public int[][] hammingTable;//hamming distance table
        public boolean flag=false;//flag if optimal code was found              
    
    //constructor 
    //sets all parameters n, d, bounds
    public Optimal(int base, int n, int distance,int M){
        this.base=base;
        this.n=n;
        this.distance=distance;
        this.M=M;
        flag=false;//setting flag to false: no optimal code found
        String [] code = new String [M];
        String [][] candidates = new String [M][(int)Math.pow(base, n)];
        candidates[0]=allPossibleCodeWords((int)Math.pow(base, n),n);
        //hamming distance table
        hammingTable =  hammingTable(allPossibleCodeWords((int)Math.pow(base, n),n));
        code[0]=candidates[0][0];
        eachLevelCandidatesSize = new int[M];
        eachLevelCandidatesSize[0]=candidates[0].length;        
        //setting initial parameters to pass to backtrack algrithm
        for(int eachW=1; eachW<eachLevelCandidatesSize[0]; eachW++){
           String wWord;
           wWord=candidates[0][eachW];
           if(hammingTable[Integer.parseInt(wWord,2)][Integer.parseInt(code[0],2)]>=distance){
               candidates[0+1][eachLevelCandidatesSize[0+1]]=wWord;
               eachLevelCandidatesSize[0+1]++;
           }
        }
        //initial call for backtrack algorithm
        backtrackAlgorithm(code,candidates,1);
        
        if (flag) {
            System.out.println();
            System.out.println("Code ("+(n)+","+M+","+(distance)+")  EXIST");
            System.out.println("Codewords of above Code are equal to Code ("+(n+1)+","+M+","+(distance+1)+")  since, distance is even");
            for(int i=0; i<optimal.length; i++)
                System.out.println((i+1)+" : "+optimal[i]);
        }else
            System.out.println("Code ("+(n+1)+","+M+","+(distance+1)+")  DOES NOT EXIST");
        
    }
    
   //This method is the main method which finds optimal code for given lenght n,
   //distance d, and upper bound M from the known table (M.R. Best, A.E. Brouwer, F.J. MacWilliams, 
    //A.M. Odlyzko & N.J.A. Sloane, Bounds for Binary Codes of Length Less than 25, 
    //IEEE Trans. Inf. Th. 24 (1978) 81-93) 
   public void backtrackAlgorithm (String [] code, String [][] candidates, int level){
   
       for(int eachV=0; eachV<eachLevelCandidatesSize[level]; eachV++){
            if (flag) return;           
            String allowedSymbol;
            allowedSymbol= candidates[level][eachV];           
            //optimization statment (improvment)
            //The candidates for a level should only contain words starting with
            //an allowed symbol.
            //Symbol 0 is allowed at any level
            //Symbol 1 is allowed only when level>=(M/base)+1
            if(( allowedSymbol.charAt(0)== '0') || ((allowedSymbol.charAt(0) == '1') 
                    && ((level+1) >= ((M-1) /base + 1))) ){            
            for (int i=level+1; i<M; i++) {
            eachLevelCandidatesSize[i] = 0;
            }        
            String vWord; 
            vWord=candidates[level][eachV];
            code[level]=vWord;
         
            if(level<M-1) { //statment for recurcive
                
                for(int eachW=eachV+1; eachW<eachLevelCandidatesSize[level]; eachW++){
                    String wWord;
                    wWord=candidates[level][eachW];
                    if(hammingTable[Integer.parseInt(vWord,2)][Integer.parseInt(wWord,2)]>=distance){
                        candidates[level+1][eachLevelCandidatesSize[level+1]]=wWord;
                        eachLevelCandidatesSize[level+1]++;
                    }
                }
                //another optimization statment (improvement)
                //looks at the candidates list at each level
                //if there are not enough candidates of the appropriate type 
                //to fill in a given section, then return
                if(eachLevelCandidatesSize[level+1]<M-level-1) return;
                backtrackAlgorithm(code,candidates,level+1);
            }else{
                optimal=code;               
                flag=true;
                return;
            }
          }else return;
        }      
   }
   
   //This method generates all binary codewords for given parameter n
   //and passes as array of String to save some memory
    public String [] allPossibleCodeWords(int row, int column){
        int [][] array = new int[row][column];    
        for (int i=1; i<array.length; i++){
            int [] subArray = array[i-1].clone();
            subArray[subArray.length-1]+=1;
            for (int j=subArray.length-1; j>=0; j--){
                if (subArray[j]!=0 && subArray[j] % 2 == 0){
                    subArray[j]=0;
                    subArray[j-1]+=1;
                }
            }
            array[i]=subArray;
        }        
        String [] allCodes = new String [array.length];        
        for (int i=0; i<array.length; i++){
            String line="";
            for (int j=0; j<array[0].length; j++){
               line=line+array[i][j]; 
            }
            allCodes[i]=line;
        }        
        return allCodes;
    }  
    
//This method precompiles Hamming distance table for given n
 //since it is most common operation in the code
    public int[][] hammingTable(String[] fullArray){
        
        int[][] hamTable = new int[fullArray.length][fullArray.length];
        for(int i=0; i<fullArray.length; i++){
            String vWord=fullArray[i];
            for (int j=0; j<fullArray.length; j++){
                String wWord=fullArray[j];
                int dis=0;
                for(int k=0; k<vWord.length(); k++){
                    if (vWord.charAt(k)!=wWord.charAt(k))
                        dis++;
                }
            hamTable[i][j]=dis;    
            }
        }   
        return hamTable;
    }

  public static void main(String[] args) {
        int base=2;// code base (binary our case)
        int n=13;//code length
        int distance=6;//distance
        int M[][]={ {},
                    {},
                    {},
                    {},
                    {4,8,16,20,40,72,144,256},
                    {},
                    {2,2,2,4,6,12,24,32},
                    }; //upper bound table for distance 4 and 6, and 6<=n<=13 
        int next=0;       
        //This loop builds optimal codewords for distance 4 or 6, and 6<=n<=13 
        //also shows that there is no code more than values given in the table
        //since I am checking for for even distance, (n-1,d-1) passed 
        for(int length=6; length<=n; length++){
            for(int bound=0; bound<2; bound++){
                Optimal x = new Optimal(base,length-1,distance-1,M[distance][next]+bound);
            }
            next++;
        }        
    }    
}
